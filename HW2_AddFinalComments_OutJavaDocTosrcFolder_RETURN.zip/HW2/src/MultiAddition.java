/**
 * This class is a Sub-Class of MultiOperations and Expression class.
 * Represents an arithmetic expression with at least two operands to add up in arithmetic calculations.
 */
public class MultiAddition extends MultiOperations {
    private final static int MINIMAL_OPERAND_NUMBER = 2;

    /**
     * Constructor for the MultiAddition class.
     * @param expressions array of at least 2 mathematical expressions.
     * Calculates the value of adding all the given expressions,
     * While making sure there were at least 2 expressions given .
     */
    public MultiAddition(Expression... expressions) {
        int numberOfOperands = expressions.length;
        if (numberOfOperands >= MINIMAL_OPERAND_NUMBER) {
            this.expressions = new Expression[numberOfOperands];
        }
        else {
            expressions = new Expression[MINIMAL_OPERAND_NUMBER];
            expressions[0] = new IntegerLiteral(0);
            expressions[1] = new IntegerLiteral(0);;
        }
        this.expression = 0;
        this.operation = " + ";

        int i = 0;
        for (Expression expression : expressions) {
            this.expressions[i++] = expression;
            this.expression += expression.evaluate();
        }
    }
}
