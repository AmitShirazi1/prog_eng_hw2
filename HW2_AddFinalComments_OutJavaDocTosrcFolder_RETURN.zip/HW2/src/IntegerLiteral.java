/**
 * This class is a Sub-Class of Expression class.
 * Represents an integer in arithmetic calculations.
 * For the sake of calculations every integer is converted to a double and is fixed before printing.
 */
public class IntegerLiteral extends NumericalExpressions {
    public IntegerLiteral(int intOperand) {
        this.expression = (double) intOperand;
    }
}
