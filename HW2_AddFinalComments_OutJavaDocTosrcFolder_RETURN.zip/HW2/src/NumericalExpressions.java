/**
 * This class is a Sub-Class of Expression class.
 *  * This class is the Super-Class of 2 other classes with the same toString() method.
 *  * Represents a numerical expression consisted of integers or decimal numbers.
 */
public abstract class NumericalExpressions extends Expression{
    /* an expression constructed of one object that represents a number */
    public String toString() {
        if (this.getClass() == IntegerLiteral.class) {
            return "("+(int)this.expression+")";
        }
        return "("+this.expression+")";
    }
}
