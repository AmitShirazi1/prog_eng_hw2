/**
 * This class is a Sub-Class of MultiOperations and Expression class.
 * Represents an arithmetic expression with at least two operands to multiply in arithmetic calculations.
 */
public class MultiMultiplication extends MultiOperations {
    /* represents the multi * expression */
    private final static int MINIMAL_OPERAND_NUMBER = 2;

    /**
     Constructor for the MultiMultiplication class.
     * @param expressions array of at least 2 mathematical expressions.
     * Calculates the value of multiplying all the given expressions,
     * while making sure there were at least 2 expressions given .
     */
    public MultiMultiplication(Expression... expressions) {
        int numberOfOperands = expressions.length;

        if (numberOfOperands >= MINIMAL_OPERAND_NUMBER) {
            this.expressions = new Expression[numberOfOperands];
        }
        else {
            expressions = new Expression[MINIMAL_OPERAND_NUMBER];
            expressions[0] = new IntegerLiteral(0);
            expressions[1] = new IntegerLiteral(0);;
        }
        this.expression = 1;
        this.operation = " * ";

        int i = 0;
        for (Expression expression : expressions) {
            if (this.expressions != null) {
                this.expressions[i++] = expression;
            }
            this.expression *= expression.evaluate();
        }
    }

}
