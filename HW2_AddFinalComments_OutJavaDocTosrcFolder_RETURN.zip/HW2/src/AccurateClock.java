/**
 * This class represents a clock that shows hours, minutes and seconds.
 * Extends the Clock class.
 */
class AccurateClock extends Clock {
    static final String ACCURATE_CLOCK_CLASS_NAME = "AccurateClock";

    private int second;

    public AccurateClock(int hour, int minute, int second) {
        super(hour, minute);
        this.second = (second < super.BEGINNING_OF_TIME ||
                second >= super.MAX_MINUTE_OR_SECOND) ? super.BEGINNING_OF_TIME : second;
        super.setClassName(CLOCK_CLASS_NAME);
    }

    /**
     * OVERRIDES the equals() method in Object and Clock classes.
     * This method compares two clocks by the time they show, by class and by name.
     * @param otherAccurateClock An object of Accurate Clock class.
     * @return True if two objects are equal and false otherwise.
     */
    @Override
    public boolean equals(Object otherAccurateClock) {
        if (this == otherAccurateClock) {
            return true;
        }
        if (otherAccurateClock == null) {
            return false;
        }

        if (!(otherAccurateClock instanceof AccurateClock)) {
            return false;
        }
        AccurateClock other = (AccurateClock) otherAccurateClock;
        if ((this.className != ACCURATE_CLOCK_CLASS_NAME) || (other.className != ACCURATE_CLOCK_CLASS_NAME)) {
            return false;
        }

        return (this.hour == other.hour && this.minute == other.minute && this.second == other.second);
    }
    /**
     * OVERRIDES the hashCode() method in Object class
     * @return A unique code that represents an AccurateClock object (used for comparison between different clocks).
     */
    @Override
    public int hashCode(){
        int hour = this.hour;
        int minute = this.minute;
        int second = this.second;
        int hash = (10000*hour)+(100*minute)+(second);
        return hash;

    }
    /**
     * OVERRIDES the toString() method in Object class.
     * This method concatenates the hours, minutes and seconds shown by the accurate clock.
     * @return A string showing the time on the current accurate clock.
     */
    @Override
    public String toString() {
        String secondsStr = String.valueOf(this.second);
        if (this.second < super.MINIMAL_2_DIGIT_NUMBER) {
            secondsStr = "0" + secondsStr;
        }
        return (super.toString() + ":" + secondsStr) ;
    }
}