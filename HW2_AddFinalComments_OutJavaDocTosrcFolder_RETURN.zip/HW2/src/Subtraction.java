/**
 * This class is a Sub-Class of ArithmeticOperations and of Expression.
 * Represents the "minus" (-) sign in arithmetic calculations.
 */
public class Subtraction extends ArithmeticOperations{

    public Subtraction(Expression firstOperand, Expression secondOperand){
        this.firstOperand = firstOperand;
        this.secondOperand = secondOperand;
        this.operation = " - ";
        this.expression = firstOperand.evaluate() - secondOperand.evaluate();
    }
}
