public class ReversePolishNotationParser extends ExpressionParser {
    //הרעיון הוא ליישם את הקייסים על פעולות החשבון בין המספרים לפי סדר מימין לשמאל
    public ReversePolishNotationParser() {
        this.isReverse = true;
    }

    public Expression parse(String reversePolishNotation) {
        //Stack to store operands
        this.stack = new Stack();
        String[] reversePolish = reversePolishNotation.split(" ");
        int expressionLenght = reversePolish.length;

        //Parse the expression - left to right
        for (int i = 0; i < expressionLenght; i++) {
            breakingDownPolishCommand(reversePolish[i]);
        }
        return this.stack.pop();
    }

}
//להדפיס עם סוגריים את הביטוי