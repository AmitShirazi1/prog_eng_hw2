/**
 * This class is a Sub-Class of ArithmeticOperations and of Expression.
 * Represents the "times" (*) sign in arithmetic calculations.
 */
public class Multiplication extends ArithmeticOperations {

    public Multiplication(Expression firstOperand, Expression secondOperand){
        this.firstOperand = firstOperand;
        this.secondOperand = secondOperand;
        this.operation = " * ";
        this.expression = firstOperand.evaluate() * secondOperand.evaluate();
    }
}
