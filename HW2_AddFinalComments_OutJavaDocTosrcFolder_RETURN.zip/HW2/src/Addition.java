/**
 * This class is a Sub-Class of ArithmeticOperations and of Expression class.
 * Represents the "plus" (+) sign in arithmetic calculations.
 */
public class Addition extends ArithmeticOperations {

    public Addition(Expression firstOperand, Expression secondOperand) {
        this.firstOperand = firstOperand;
        this.secondOperand = secondOperand;
        this.operation = " + ";
        this.expression = firstOperand.evaluate() + secondOperand.evaluate();
    }
}
