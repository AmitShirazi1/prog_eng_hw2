/**
 * This class is a Sub-Class of Expression class.
 * Represents a decimal number in arithmetic calculations.
 */
public class DoubleLiteral extends NumericalExpressions {
    public DoubleLiteral(double doubleOperand) {
        this.expression = doubleOperand;
    }
}
