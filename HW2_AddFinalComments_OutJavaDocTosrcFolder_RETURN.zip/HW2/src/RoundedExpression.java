/**
 * This class is a Sub-Class of Expression class.
 * Represents the round action of numbers after decimal point in an arithmetic expression.
 */
public class RoundedExpression extends Expression {
    public Expression valueBeforeRound;

    public RoundedExpression (Expression expression, int digitsAfterDecimalPoint){
        this.valueBeforeRound = expression;
        this.expression = Math.round(this.valueBeforeRound.evaluate() * Math.pow(10, digitsAfterDecimalPoint))
                                / Math.pow(10, digitsAfterDecimalPoint);
    }

    public String toString() {
        return this.valueBeforeRound.toString();
    }
}