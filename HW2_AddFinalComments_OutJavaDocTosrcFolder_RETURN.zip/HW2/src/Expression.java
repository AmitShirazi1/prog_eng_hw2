/**
 * This class represents an arithmetic expression and is the Super-Class of 13 Sub-Classes (each will be mentioned on
 * its own).
 */
public abstract class Expression {
    public double expression;

    /**
     * Calculates the current expression's numeral value.
     * @return the numeral value as double.
     */
    public double evaluate(){
        return this.expression;
    }

    /**
     * OVERRIDES the toString function of String class.
     * Converts the current mathematical expression to a string, in accordance to a format with brackets.
     * @return string that represents the mathematical expression.
     */
    @Override
    public abstract String toString();
}
