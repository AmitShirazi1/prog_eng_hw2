/**
 * This class is a Sub-Class of Expression class.
 *  * Represents an Additive inverse of a number (-x if x>0 and x if x<0) in arithmetic calculations.
 */
public class UnaryMinus extends Expression {
    private Expression unaryMinusExpression;

    public UnaryMinus (Expression expression) {
        this.unaryMinusExpression = expression;
        this.expression = (-1) * expression.evaluate();
    }
    /**
     * Converts the current arithmetic expression to a string, according to the UnaryMinus operation,
     * while making sure none of the operands in the calculation are missing (null).
     * @return string that represents the arithmetic expression with the Additive inverse of the operands
     * manipulated by the UnaryMinus operator.
     */
    public String toString() {
        return "(-" + this.unaryMinusExpression.toString() + ")";
    }
}
