/**
 * This class is a Sub-Class of ArithmeticOperations and of Expression.
 * Represents the "divided by" (/) sign in arithmetic calculations.
 */
public class Division extends ArithmeticOperations{

    public Division (Expression firstOperand, Expression secondOperand){
        this.firstOperand = firstOperand;
        this.secondOperand = secondOperand;
        this.operation = " / ";
        this.expression = (double) firstOperand.evaluate() / secondOperand.evaluate();
    }
}
