/**
 * This class is a Sub-Class of Expression class.
 * This class is the Super-Class of 2 other classes with the same toString() method.
 * Represents an arithmetical operation constructs of multiple operands at once.
 */
public abstract class MultiOperations extends Expression {
    /* Operations between numerous numbers */
    protected Expression[] expressions;
    protected String operation;

    /**
     * Converts the current arithmetic expression to a string, in accordance to a format with brackets,
     * While making sure there are operands in the current expression, to avoid errors.
     * @return string that represents the arithmetic expression.
     */
    public String toString() {
        String multiExpression = "(";
        int i=0;
        if (this.expressions != null) {
            for (Expression expression : this.expressions) {
                if (i>0) {
                    multiExpression = multiExpression.concat(this.operation);
                }
                if (expression != null) {
                    multiExpression = multiExpression.concat(expression.toString());
                }
                i++;
            }
            return multiExpression + ")";
        }
        return null;
    }
}
