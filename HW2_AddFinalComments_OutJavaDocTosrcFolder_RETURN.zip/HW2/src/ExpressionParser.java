/**
 *This class is responsible for the parsing of the Polish and ReversePolish expressions entered by the user.
 */
public abstract class ExpressionParser {
    protected boolean isReverse;
    public Stack stack;

    protected Expression operand1;
    protected Expression operand2;
    protected Expression result;
    protected double operandDouble;
    protected int operandInt;

    public abstract Expression parse(String polishNotation);

    /**
     * This method breaks down and calculates the expression given by the user according to a set of rules.
     * @param currentPartOfCommand The current operand or operator we're checking
     */
    public void breakingDownPolishCommand(String currentPartOfCommand) {
        switch (currentPartOfCommand) {
            case "+":
                popOutOfStack();
                this.result = new Addition(this.operand1, this.operand2);
                this.stack.push(this.result);
                break;
            case "-":
                popOutOfStack();
                this.result = new Subtraction(this.operand1, this.operand2);
                this.stack.push(this.result);
                break;
            case "*":
                popOutOfStack();
                this.result = new Multiplication(this.operand1, this.operand2);
                this.stack.push(this.result);
                break;
            case "/":
                popOutOfStack();
                this.result = new Division(this.operand1, this.operand2);
                this.stack.push(this.result);
                break;
            case "-u":
                this.operand1 = this.stack.pop();
                this.result = new UnaryMinus(this.operand1);
                this.stack.push(this.result);
                break;
            default:
                // it's a number
                if (currentPartOfCommand.contains(".")) {
                    this.operandDouble = Double.parseDouble(currentPartOfCommand);
                    this.result = new DoubleLiteral(this.operandDouble);
                    this.stack.push(this.result);
                } else {
                    this.operandInt = Integer.parseInt(currentPartOfCommand);
                    this.result = new IntegerLiteral(this.operandInt);
                    this.stack.push(this.result);
                }
        }
    }

    /**
     * A method defining the operands according to type of Polish Notation (Reverse or regular)
     */
    private void popOutOfStack() {
        if (this.isReverse) {
            this.operand2 = this.stack.pop();
            this.operand1 = this.stack.pop();
        }
        else {
            this.operand1 = this.stack.pop();
            this.operand2 = this.stack.pop();
        }
    }
}

