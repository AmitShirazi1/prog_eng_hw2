/**
 *This class is a Sub-Class of ExpressionParser class.
 * Represents an expression written in PolishNotation format.
 */
public class PolishNotationParser extends ExpressionParser {
    public PolishNotationParser() {
        this.isReverse = false;
    }

    /**
     * This method parses the expression entered by the user by empty spaces.
     * @param polishNotation The expression to calculate.
     * @return
     */
    public Expression parse(String polishNotation) {
        //Stack to store operands
        this.stack = new Stack();
        String[] polishCommand = polishNotation.split(" ");
        int expressionLenght = polishCommand.length;

        //Parse the expression - right to left
        for (int i = expressionLenght-1; i >= 0; i--) {
            breakingDownPolishCommand(polishCommand[i]);
        }
        return this.stack.pop();
    }
}
