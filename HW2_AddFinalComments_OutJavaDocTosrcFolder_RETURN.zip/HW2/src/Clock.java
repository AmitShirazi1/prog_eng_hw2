/**
 *This class represents a clock that shows hours and minutes.
 */
class Clock {
    static final int BEGINNING_OF_TIME = 0;
    static final int MAX_HOUR = 24;
    static final int MAX_MINUTE_OR_SECOND = 60;
    static final int MINIMAL_2_DIGIT_NUMBER = 10;
    static final String CLOCK_CLASS_NAME = "Clock";

    protected int hour;
    protected int minute;
    protected String className;

    public Clock(int hour, int minute) {
        this.hour = (hour < BEGINNING_OF_TIME || hour >= MAX_HOUR) ? BEGINNING_OF_TIME : hour;
        this.minute = (minute < BEGINNING_OF_TIME || minute >= MAX_MINUTE_OR_SECOND) ? BEGINNING_OF_TIME : minute;

    }

    /**
     * This method gets the name of the class - "Clock"
     * @param name A string containing the name of the object's class.
     */
    public void setClassName(String name) {
        this.className = name;
    }

    /**
     * OVERRIDES the equals() method in Object class.
     * This method compares two clocks by the time they show, by class and by name.
     * @param other_clock An object of Clock class.
     * @return True if two objects are equal and false otherwise.
     */
    @Override
    public boolean equals(Object other_clock) {
        if (this == other_clock) {
            return true;
        }
        if (other_clock == null) {
            return false;
        }

        if (!(other_clock instanceof Clock)) {
            return false;
        }
        Clock other = (Clock) other_clock;
        if ((this.className != CLOCK_CLASS_NAME) || (other.className != CLOCK_CLASS_NAME)) {
            return false;
        }

        return (this.hour == other.hour && this.minute == other.minute);
    }

    /**
     * OVERRIDES the hashCode() method in Object class
     * @return A unique code that represents a clock object (used for comparison between different clocks).
     */
    @Override
    public int hashCode(){
        int hour = this.hour;
        int minute = this.minute;
        int hash = (100*hour)+(minute);
        return hash;
    }

    /**
     * OVERRIDES the toString() method in Object class.
     * This method concatenates the hours and minutes shown by the clock.
     * @return A string showing the time on the current clock.
     */
    @Override
    public String toString() {
        String hourStr = String.valueOf(this.hour);
        if (this.hour < MINIMAL_2_DIGIT_NUMBER) {
            hourStr = "0" + hourStr;
        }
        String minuteStr = String.valueOf(this.minute);
        if (this.minute < MINIMAL_2_DIGIT_NUMBER) {
            minuteStr = "0" + minuteStr;
        }
        return (hourStr + ":" + minuteStr) ;
    }
}

