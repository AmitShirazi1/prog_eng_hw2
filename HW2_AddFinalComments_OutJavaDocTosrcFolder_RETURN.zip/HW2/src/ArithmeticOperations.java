/**
 * This class is a Sub-Class of Expression class.
 * This class is the Super-Class of 4 other classes with the same toString() method.
 * Represents an arithmetic operation between 2 operands.
 */
public abstract class ArithmeticOperations extends Expression {
    protected Expression firstOperand;
    protected Expression secondOperand;
    protected String operation;

    /**
     * Converts the current arithmetic expression to a string, in accordance to a format with brackets,
     * While making sure none of the operands in the calculation are missing (null).
     * @return string that represents the arithmetic expression.
     */
    public String toString(){
        if ((this.firstOperand != null) && (this.operation != null) && (this.secondOperand != null)) {
            return "(" + this.firstOperand.toString() + this.operation + this.secondOperand.toString() + ")";
        }
        return null;
    }
}
